'use strict'
const path = require('path')
const fs   = require('fs')

const standaloneServer = path.join(__dirname, '.next', 'standalone', 'server.js')

if (!fs.existsSync(standaloneServer)) {
  console.error('───────────────────────────────────────────────')
  console.error('App not built yet. SSH into the server and run:')
  console.error('  npm install && npm run build')
  console.error('Then restart the Node.js app in hPanel.')
  console.error('───────────────────────────────────────────────')
  process.exit(1)
}

require(standaloneServer)
