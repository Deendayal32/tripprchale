#!/usr/bin/env bash
# Run this once via SSH after uploading the zip:
#   bash setup.sh
set -e
echo "Installing dependencies (including optional native binaries for Linux)..."
npm install --include=optional
echo "Building Next.js app..."
npm run build
echo ""
echo "Done! Restart the app in hPanel → Node.js → Restart"
