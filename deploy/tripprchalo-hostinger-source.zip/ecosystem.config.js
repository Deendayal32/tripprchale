module.exports = {
  apps: [
    {
      name: 'tripprchale',
      script: 'server.js',
      cwd: '/home/u123456/domains/yourdomain.com/public_nodejs',
      instances: 1,
      exec_mode: 'fork',
      env: {
        NODE_ENV: 'production',
        PORT: 3000,
        HOSTNAME: '0.0.0.0',
      },
      watch: false,
      max_memory_restart: '512M',
    },
  ],
}
